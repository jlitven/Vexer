import anki

print anki.__all__
