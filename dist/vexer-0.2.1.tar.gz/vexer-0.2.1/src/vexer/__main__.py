#! /usr/bin/python

if __name__ == '__main__':
    from vocabulary_creator import main
    main()
